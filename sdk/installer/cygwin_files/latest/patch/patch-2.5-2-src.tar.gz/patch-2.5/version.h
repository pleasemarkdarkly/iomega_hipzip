/* Print the version number.  */

/* $Id: version.h,v 1.3 1997/04/07 01:07:00 eggert Exp $ */

void version PARAMS ((void));
