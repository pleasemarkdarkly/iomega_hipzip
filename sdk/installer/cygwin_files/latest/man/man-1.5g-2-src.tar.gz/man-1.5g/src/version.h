static char version[] = "1.5f";
