extern char *mandir_of (char *name);
extern char *convert_to_cat (char *name, char *ext, int standards);
