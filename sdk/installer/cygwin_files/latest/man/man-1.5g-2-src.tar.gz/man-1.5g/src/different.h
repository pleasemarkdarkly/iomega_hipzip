int different_cat_file (char *file);
int different_man_file (char *file);
