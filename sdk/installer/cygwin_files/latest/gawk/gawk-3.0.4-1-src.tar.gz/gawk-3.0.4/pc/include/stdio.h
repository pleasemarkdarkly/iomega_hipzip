#undef __STDC__
#include <stdio.h>
#define __STDC__ 1
