/* netinet/tcp.h

   Copyright 2000, 2001 Red Hat, Inc.

This file is part of Cygwin.

This software is a copyrighted work licensed under the terms of the
Cygwin license.  Please consult the file "CYGWIN_LICENSE" for
details. */

#ifndef _NETINET_TCP_H
#define _NETINET_TCP_H

/* Maybe add some definitions, someday */

#endif
