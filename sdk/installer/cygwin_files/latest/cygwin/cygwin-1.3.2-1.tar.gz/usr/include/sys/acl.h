/* sys/acl.h header file for Cygwin.

   Copyright 1999, 2000 Cygnus Solutions.
   Written by C. Vinschen.

This file is part of Cygwin.

This software is a copyrighted work licensed under the terms of the
Cygwin license.  Please consult the file "CYGWIN_LICENSE" for
details. */

#ifndef _SYS_ACL_H
#define _SYS_ACL_H

#include <cygwin/acl.h>

#endif /* _SYS_ACL_H */
