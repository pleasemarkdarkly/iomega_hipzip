/* Special definitions for GNU tar, processed by autoheader.
   Copyright 1994, 1997, 1999, 2000 Free Software Foundation, Inc.
   Fran�ois Pinard <pinard@iro.umontreal.ca>, 1993.  */

/* Define to `int' if <sys/types.h> doesn't define.  */
#undef daddr_t

/* Define to `int' if <sys/types.h> doesn't define.  */
#undef major_t

/* Define to `int' if <sys/types.h> doesn't define.  */
#undef minor_t

/* Define to `int' if <sys/types.h> doesn't define.  */
#undef ssize_t
