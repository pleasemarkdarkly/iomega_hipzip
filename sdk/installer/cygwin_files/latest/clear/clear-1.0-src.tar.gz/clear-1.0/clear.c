main()
{
  write (1, "\033[1;1H\033[2J", 10);
  return 0;
}
