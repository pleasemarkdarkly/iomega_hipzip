
GLUT, GLU and OpenGL header files; GLUT DLL; GLUI and GLUIX header files and libraries
--------------------------------------------------------------------------------------

Andr� Bleau, bleau@igb.umontreal.ca

Package opengl-1.1.0-5 updated 11/05/2001


*** WARNING ***
---------------

This package does _not_ contain a complete set of files for building Open GL
-based programs. It contains only the missing pieces in the Cygwin environment
to build programs calling functions from opengl32.dll and glu32.dll provided 
by Microsoft in Windows 98, Windows ME, Windows NT 4.0 and Windows 2000. 

For Windows 95, you need to download: 
http://download.microsoft.com/download/win95upg/info/1/W95/EN-US/Opengl95.exe . 

This package also contains an include file and a DLL for for building 
GLUT-based programs and an include files and static libraries for 
GLUI and GLUIX-based programs.



Installation
------------

Use the setup utility from www.cygwin.com.

Be carefull that no programs using glut32.dll has been run for some time; otherwise 
setup will be unable to replace it.


Compilation of code calling OpenGL
----------------------------------

Programs can now be compiled with and without -mno-cygwin .
Add the following include statement to your code:

#include <GL/gl.h>

This will give you function prototypes and defined constants for OpenGL 1.1.0
provided by Microsoft. If you somehow obtained an OpenGL 1.2.1 DLL (from your 
graphic card provider) and want to use OpenGL 1.2.1 functionality, add the 
following option to your compilation command: -DGL_VERSION_1_2 .


Compilation of code calling GLU
-------------------------------

Programs can now be compiled with and without -mno-cygwin .
Add the following include statements to your code:

#include <GL/gl.h>
#include <GL/glu.h>

This will give you function prototypes and defined constants for GLU 1.2
provided by Microsoft. If you somehow obtained a GLUL 1.3 DLL (from your 
graphic card provider) and want to use GLU 1.3 functionality, add the 
following option to your compilation command: -DGLU_VERSION_1_3 .


Compilation of code calling GLUT
--------------------------------

Programs can now be compiled with and without -mno-cygwin .
Add the following include statement to your code:

#include <GL/glut.h>


Compilation of code calling GLUI
--------------------------------

Add the following include statements to your code:

#include <GL/glut.h>
#include <glui.h>


Compilation of code calling GLUIX
---------------------------------

Add the following include statements to your code:

#include <GL/glut.h>
#include <glui.h>
#include <gluix.h>


Linking of code calling OpenGL
------------------------------

Programs can now be linked with and without -mno-cygwin .

Add -lopengl32 to your link command.


Linking of code calling OpenGL, GLU
-----------------------------------

Programs can now be linked with and without -mno-cygwin .

Add -lglu32 -lopengl32 to your link command (in that order).


Linking of code calling OpenGL, GLU, GLUT
-----------------------------------------

Programs can now be linked with and without -mno-cygwin .

Add -lglut32 -lglu32 -lopengl32 to your link command (in that order).


Linking of code calling OpenGL, GLU, GLUT, and GLUI
---------------------------------------------------

Add -lglui -lglut32 -lglu32 -lopengl32 to your link 
command (in that order). 


Linking of code calling OpenGL, GLU, GLUT, GLUI, and GLUIX
----------------------------------------------------------

Add -lgluix -lglui -lglut32 -lglu32 -lopengl32 to your link 
command (in that order). 


Compilation and linking of code calling GLUI and/or GLUIX with -mno-cygwin
--------------------------------------------------------------------------

GLUI and GLUIX are C++ librairies, for which there is currently no support by Cygwin
when compiling with -mno-cygwin. However, if you are adventurous, you could add the
missing pieces to your Cygwin installation:

1- Download gcc-2.95.2-3.zip from http://sourceforge.net:80/projects/mingw
2- Unzip
3- Copy the g++-3 directory from include to /usr/include/mingw
4- Copy libstdc++.a from lib/gcc-lib/mingw32/2.95.2 to /usr/lib/mingw

You will need the following Cygwin packages (or more recent) for this to work:
	mingw-20010424-1
	gcc-2.95.3-3


Add -lgluix -lglui -lglut32 -lglu32 -lopengl32 to your link 
command (in that order). 


Librairies
----------

libglui.a and libgluix.a are static libraries.

libglu32.a and libopengl32.a interface with DLLs from Windows 
NT/2000/95/98/ME. They are part of Cygwin 1.x.y.

libglut32.a interface with the glut32.dll from this package.


Content of the tar ball
-----------------------

        usr/bin/glut32.dll
For GLUT 3.7.3
From http://www.xmission.com:80/~nate/glut.html; not modified.

	usr/doc/opengl-1.1.0/README.txt
This file.

	usr/doc/opengl-1.1.0/glui_manual_v2_beta.pdf
For GLUI 2.0 beta.
From http://www.cs.unc.edu/~rademach/glui/ . Documentation for
GLUI 2.10 beta.

	usr/doc/opengl-1.1.0/glui_menuButton.pdf
	usr/doc/opengl-1.1.0/glui_panel.pdf
	usr/doc/opengl-1.1.0/glui_windows.pdf
For GLUI 2.11 beta.
Documentation addenda for GLUI 2.11 beta.

	usr/doc/opengl-1.1.0/gluix.pdf
For GLUIX 1.01.
Documentation for GLUIX 1.01.

	usr/doc/opengl-1.1.0/glut-3.spec.pdf
For GLUT 3.7.x
From http://reality.sgi.com/mjk_asd/glut3/glut3.html . Documentation for
GLUT 3.7.x

        usr/include/GL/gl.h
For OpenGL 1.1.0.
Modified version of usr/X11R6/include/GL/gl.h from 
ftp://sourceware.cygnus.com/pub/cygwin/xfree/xc-4-binaries/xfree86-4.0-devel.tar.bz2 
to add __attribute__ ((__stdcall__)) to the declaration of functions to 
enable linking with opengl32.dll via usr/lib/libopengl32.a .
OpenGL 1.2.1 functionality is segregated and accessible by defining GL_VERSION_1_2.

        usr/include/GL/glu.h
For GLU 1.2.2.
Modified version of usr/X11R6/include/GL/glu.h from 
ftp://sourceware.cygnus.com/pub/cygwin/xfree/xc-4-binaries/xfree86-4.0-devel.tar.bz2 
to add __attribute__ ((__stdcall__)) to the declaration of functions to 
enable linking with glu32.dll via usr/lib/libglu32.a .
GLU 1.3 functionality is segregated and accessible by defining GLU_VERSION_1_3.

        usr/include/GL/glut.h
For GLUT 3.7.3
From http://www.xmission.com:80/~nate/glut.html; modified to add 
__attribute__ ((__stdcall__)) to the declaration of functions to enable 
linking with glut32.dll via usr/lib/libglut32.a . Jerome G. Benoit 
provided hints about how to do it and provided an example; thanks Jerome!

        usr/include/glui.h
For GLUI 2.11 beta.
From http://www.cs.unc.edu/~rademach/glui/; modified to include version 2.11 additions.
Header file for the GLUI tool kit version 2.11 beta.

        usr/include/gluix.h
For GLUIX 1.01
Header file for extensions to the GLUI tool kit.

        usr/include/mingw/GL
A symbolic link to usr/include/GL .

        usr/include/mingw/glui.h
A symbolic link to usr/include/glui.h .

        usr/include/mingw/gluix.h
A symbolic link to usr/include/gluix.h .

        usr/lib/libglui.a
For GLUI 2.11 beta.
A static library compiled from modified sources of the GLUI tool kit 
version 2.10 beta, found at http://www.cs.unc.edu/~rademach/glui/. 
Compilation with -O2 optimization. I highly recommend this very useful 
tool kit.

        usr/lib/libgluix.a
For GLUIX 1.01.
A static library for extensions to the GLUI tool kit.
Compilation with -O2 optimization.

        usr/lib/mingw/libglui.a
Same as usr/lib/libglui.a , but for -mno-cygwin .

        usr/lib/mingw/libgluix.a
Same as usr/lib/libgluix.a , but for -mno-cygwin .

Modified sections of the .h files are bracketed by
#if defined(__CYGWIN__) || defined(__MINGW32__)
#endif



What has changed since opengl-1.1.0-4
-------------------------------------

The declaration of glGetString in gl.h was creating compilation errors in the 
particular case where #include <GL/gl.h> was preceded by #include <windows.h> . 
This has been corrected.



What has changed since opengl-1.1.0-3
-------------------------------------

Added support for -mno-cygwin compilation and linking.

OpenGL header now provides only 1.1.0 functionality by default. 1.2.1 functionality
can be accessed by defining GL_VERSION_1_2 .

GLU header now provides only 1.2 functionality by default. 1.3 functionality
can be accessed by defining GLU_VERSION_1_3 .

GLUT has beed upgraded from 3.7.2 to 3.7.3.

GLUI has been upgraded from 2.02 beta to 2.11 beta.

GLUIX has been upgraded from 1.00 to 1.01.


What has changed since opengl-1.1.0-2
-------------------------------------

GLUI has been updated to version 2.02.

GLUIX version 1.0 has been added to the package.

The package now installs in /usr instead of /usr/local. If you had a previous version
of the opengl package installed, you may delete the following files:
	/READMEopengl-1.1.0-2.txt
        /usr/local/include/GL/glut.h
        /usr/local/bin/glut32.dll
	/usr/local/doc/opengl-1.1.0/glui_manual_v2_beta.pdf
	/usr/local/doc/opengl-1.1.0/glut-3.spec.pdf
        /usr/local/include/GL/gl.h
        /usr/local/include/GL/glu.h
        /usr/local/include/glui.h
        /usr/local/lib/libglui.a


What has changed since opengl-1.2.1-1
-------------------------------------

The previous package name errounously suggested that it was for Open GL 1.2.1 while
it is in fact for the Open GL 1.1.0 DLL provided by Microsoft.

The declaration of glGetString in gl.h has been corrected to include the APIENTRY
qualifier.

