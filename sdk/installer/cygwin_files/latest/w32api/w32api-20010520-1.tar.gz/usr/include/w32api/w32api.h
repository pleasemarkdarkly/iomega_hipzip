#ifndef _W32API_H_
#define _W32API_H_

#define __W32API_VERSION 0.5
#define __W32API_MAJOR_VERSION 0
#define __W32API_MINOR_VERSION 5

#endif /* ndef _W32API_H_ */
