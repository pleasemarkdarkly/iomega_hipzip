/* clock.c - operations on struct tms and clock_t's */

/* Copyright (C) 1999 Free Software Foundation, Inc.

   This file is part of GNU Bash, the Bourne Again SHell.

   Bash is free software; you can redistribute it and/or modify it under
   the terms of the GNU General Public License as published by the Free
   Software Foundation; either version 2, or (at your option) any later
   version.

   Bash is distributed in the hope that it will be useful, but WITHOUT ANY
   WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
   for more details.

   You should have received a copy of the GNU General Public License along
   with Bash; see the file COPYING.  If not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307, USA */

#include <config.h>

#if defined (HAVE_TIMES)

#include <sys/types.h>
#include <posixtime.h>

#if defined (HAVE_SYS_TIMES_H)
#  include <sys/times.h>
#endif

#include <stdio.h>

void
clock_t_to_secs (t, sp, sfp)
     clock_t t;
     long *sp;
     int *sfp;
{
  static long clk_tck = -1;

  if (clk_tck == -1)
    clk_tck = get_clk_tck ();

  *sfp = t % clk_tck;
  *sfp = (*sfp * 1000) / clk_tck;

  *sp = t / clk_tck;

  /* Sanity check */
  if (*sfp >= 1000)
    {
      *sp += 1;
      *sfp -= 1000;
    }
}

/* Print the time defined by a clock_t (returned by the `times' and `time'
   system calls) in a standard way to stdio stream FP.  This is scaled in
   terms of the value of CLK_TCK, which is what is returned by the
   `times' call. */
void
print_clock_t (fp, t)
     FILE *fp;
     clock_t t;
{
  int minutes, seconds_fraction;
  long seconds;

  clock_t_to_secs (t, &seconds, &seconds_fraction);

  minutes = seconds / 60;
  seconds %= 60;

  fprintf (fp, "%0dm%0ld.%03ds",  minutes, seconds, seconds_fraction);
}
#endif /* HAVE_TIMES */

