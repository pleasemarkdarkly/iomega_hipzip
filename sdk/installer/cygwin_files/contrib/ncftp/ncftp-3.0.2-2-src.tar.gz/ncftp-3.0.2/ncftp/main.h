/* main.h
 *
 * Copyright (c) 1992-2000 by Mike Gleason.
 * All rights reserved.
 * 
 */

/* main.c */
void InitConnectionInfo(void);
void CloseHost(void);
int main(int, const char **const);
