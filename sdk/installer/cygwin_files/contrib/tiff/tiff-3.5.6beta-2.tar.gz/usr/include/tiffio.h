/* $Header: /cvsroot/osrs/libtiff/libtiff/tiffio.h,v 1.7 2000/11/13 14:42:38 warmerda Exp $ */

/*
 * Copyright (c) 1988-1997 Sam Leffler
 * Copyright (c) 1991-1997 Silicon Graphics, Inc.
 *
 * Permission to use, copy, modify, distribute, and sell this software and 
 * its documentation for any purpose is hereby granted without fee, provided
 * that (i) the above copyright notices and this permission notice appear in
 * all copies of the software and related documentation, and (ii) the names of
 * Sam Leffler and Silicon Graphics may not be used in any advertising or
 * publicity relating to the software without the specific, prior written
 * permission of Sam Leffler and Silicon Graphics.
 * 
 * THE SOFTWARE IS PROVIDED "AS-IS" AND WITHOUT WARRANTY OF ANY KIND, 
 * EXPRESS, IMPLIED OR OTHERWISE, INCLUDING WITHOUT LIMITATION, ANY 
 * WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 * 
 * IN NO EVENT SHALL SAM LEFFLER OR SILICON GRAPHICS BE LIABLE FOR
 * ANY SPECIAL, INCIDENTAL, INDIRECT OR CONSEQUENTIAL DAMAGES OF ANY KIND,
 * OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
 * WHETHER OR NOT ADVISED OF THE POSSIBILITY OF DAMAGE, AND ON ANY THEORY OF 
 * LIABILITY, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE 
 * OF THIS SOFTWARE.
 */

#ifndef _TIFFIO_
#define	_TIFFIO_

/*
 * TIFF I/O Library Definitions.
 */
#include "tiff.h"
#include "tiffvers.h"

#if defined(__CYGWIN__)
#  if defined(ALL_STATIC)
#    if defined(TIFF_DLL)
#      undef TIFF_DLL
#    endif
#    if !defined(TIFF_STATIC)
#      define TIFF_STATIC
#    endif
#  endif
#  if defined(TIFF_DLL)
#    if defined(TIFF_STATIC)
#      undef TIFF_STATIC
#    endif
#  endif
#  if defined(TIFF_DLL)
/* building a DLL */
#    define TIFF_IMPEXP __declspec(dllexport)
#  elif defined(TIFF_STATIC)
/* building or linking to a static library */
#    define TIFF_IMPEXP
#  else
/* linking to the DLL */
#    define TIFF_IMPEXP __declspec(dllimport)
#  endif
#  if !defined(TIFF_API)
#    define TIFF_API __cdecl
#  endif
#  if !defined(TIFF_EXPORT)
#    define TIFF_EXPORT(type,symbol) TIFF_IMPEXP type TIFF_API symbol
#  endif
#  if !defined(TIFF_EXPORT_VAR)
#    define TIFF_EXPORT_VAR(type) TIFF_IMPEXP type
#  endif
#endif

#if !defined(TIFF_IMPEXP)
#  define TIFF_IMPEXP
#endif
#if !defined(TIFF_API)
#  define TIFF_API
#endif
#if !defined(TIFF_EXPORT)
#  define TIFF_EXPORT(type,symbol) TIFF_IMPEXP type TIFF_API symbol
#endif
#if !defined(TIFF_EXPORT_VAR)
#  define TIFF_EXPORT_VAR(type) TIFF_IMPEXP type
#endif

/* This macro protects against machines that don't have
 * function prototypes (ie K&R style headers).
 */ 
#if !defined(TIFF_ARGS)
#  if (!defined(STDC) && !defined(__STDC__)) || defined(_NO_PROTO)
#    define TIFF_ARGS(args)  ()
#  else
#    define TIFF_ARGS(args)  args
#  endif
#endif

/*
 * TIFF is defined as an incomplete type to hide the
 * library's internal data structures from clients.
 */
typedef	struct tiff TIFF;

/*
 * The following typedefs define the intrinsic size of
 * data types used in the *exported* interfaces.  These
 * definitions depend on the proper definition of types
 * in tiff.h.  Note also that the varargs interface used
 * to pass tag types and values uses the types defined in
 * tiff.h directly.
 *
 * NB: ttag_t is unsigned int and not unsigned short because
 *     ANSI C requires that the type before the ellipsis be a
 *     promoted type (i.e. one of int, unsigned int, pointer,
 *     or double) and because we defined pseudo-tags that are
 *     outside the range of legal Aldus-assigned tags.
 * NB: tsize_t is int32 and not uint32 because some functions
 *     return -1.
 * NB: toff_t is not off_t for many reasons; TIFFs max out at
 *     32-bit file offsets being the most important, and to ensure
 *     that it is unsigned, rather than signed.
 */
typedef	uint32 ttag_t;		/* directory tag */
typedef	uint16 tdir_t;		/* directory index */
typedef	uint16 tsample_t;	/* sample number */
typedef	uint32 tstrip_t;	/* strip number */
typedef uint32 ttile_t;		/* tile number */
typedef	int32 tsize_t;		/* i/o size in bytes */
typedef	void* tdata_t;		/* image data ref */
typedef	uint32 toff_t;		/* file offset */

#if !defined(__WIN32__) && (defined(_WIN32) || defined(WIN32)) && !defined(__CYGWIN__)
#define __WIN32__
#endif

/*
 * On windows you should define USE_WIN32_FILEIO if you are using tif_win32.c
 * or AVOID_WIN32_FILEIO if you are using something else (like tif_unix.c).
 *
 * By default tif_win32.c is assumed on windows if not using the cygwin
 * environment.
 */

#if defined(_WINDOWS) || defined(__WIN32__) || defined(_Windows)
#  if !defined(__CYGWIN__) && !defined(AVOID_WIN32_FILEIO) && !defined(USE_WIN32_FILIO)
#    define USE_WIN32_FILEIO
#  endif
#endif

#if defined(USE_WIN32_FILEIO)
#include <windows.h>
#ifdef __WIN32__
DECLARE_HANDLE(thandle_t);	/* Win32 file handle */
#else
typedef	HFILE thandle_t;	/* client data handle */
#endif
#else
typedef	void* thandle_t;	/* client data handle */
#endif

#ifndef NULL
#define	NULL	0
#endif

/*
 * Flags to pass to TIFFPrintDirectory to control
 * printing of data structures that are potentially
 * very large.   Bit-or these flags to enable printing
 * multiple items.
 */
#define	TIFFPRINT_NONE		0x0		/* no extra info */
#define	TIFFPRINT_STRIPS	0x1		/* strips/tiles info */
#define	TIFFPRINT_CURVES	0x2		/* color/gray response curves */
#define	TIFFPRINT_COLORMAP	0x4		/* colormap */
#define	TIFFPRINT_JPEGQTABLES	0x100		/* JPEG Q matrices */
#define	TIFFPRINT_JPEGACTABLES	0x200		/* JPEG AC tables */
#define	TIFFPRINT_JPEGDCTABLES	0x200		/* JPEG DC tables */

/*
 * RGBA-style image support.
 */
typedef	unsigned char TIFFRGBValue;		/* 8-bit samples */
typedef struct _TIFFRGBAImage TIFFRGBAImage;
/*
 * The image reading and conversion routines invoke
 * ``put routines'' to copy/image/whatever tiles of
 * raw image data.  A default set of routines are 
 * provided to convert/copy raw image data to 8-bit
 * packed ABGR format rasters.  Applications can supply
 * alternate routines that unpack the data into a
 * different format or, for example, unpack the data
 * and draw the unpacked raster on the display.
 */
typedef void (*tileContigRoutine)
    (TIFFRGBAImage*, uint32*, uint32, uint32, uint32, uint32, int32, int32,
	unsigned char*);
typedef void (*tileSeparateRoutine)
    (TIFFRGBAImage*, uint32*, uint32, uint32, uint32, uint32, int32, int32,
	unsigned char*, unsigned char*, unsigned char*, unsigned char*);
/*
 * RGBA-reader state.
 */
typedef struct {				/* YCbCr->RGB support */
	TIFFRGBValue* clamptab;			/* range clamping table */
	int*	Cr_r_tab;
	int*	Cb_b_tab;
	int32*	Cr_g_tab;
	int32*	Cb_g_tab;
	float	coeffs[3];			/* cached for repeated use */
} TIFFYCbCrToRGB;

struct _TIFFRGBAImage {
	TIFF*	tif;				/* image handle */
	int	stoponerr;			/* stop on read error */
	int	isContig;			/* data is packed/separate */
	int	alpha;				/* type of alpha data present */
	uint32	width;				/* image width */
	uint32	height;				/* image height */
	uint16	bitspersample;			/* image bits/sample */
	uint16	samplesperpixel;		/* image samples/pixel */
	uint16	orientation;			/* image orientation */
	uint16	photometric;			/* image photometric interp */
	uint16*	redcmap;			/* colormap pallete */
	uint16*	greencmap;
	uint16*	bluecmap;
						/* get image data routine */
	int	(*get)(TIFFRGBAImage*, uint32*, uint32, uint32);
	union {
	    void (*any)(TIFFRGBAImage*);
	    tileContigRoutine	contig;
	    tileSeparateRoutine	separate;
	} put;					/* put decoded strip/tile */
	TIFFRGBValue* Map;			/* sample mapping array */
	uint32** BWmap;				/* black&white map */
	uint32** PALmap;			/* palette image map */
	TIFFYCbCrToRGB* ycbcr;			/* YCbCr conversion state */

        int	row_offset;
        int     col_offset;
};

/*
 * Macros for extracting components from the
 * packed ABGR form returned by TIFFReadRGBAImage.
 */
#define	TIFFGetR(abgr)	((abgr) & 0xff)
#define	TIFFGetG(abgr)	(((abgr) >> 8) & 0xff)
#define	TIFFGetB(abgr)	(((abgr) >> 16) & 0xff)
#define	TIFFGetA(abgr)	(((abgr) >> 24) & 0xff)

/*
 * A CODEC is a software package that implements decoding,
 * encoding, or decoding+encoding of a compression algorithm.
 * The library provides a collection of builtin codecs.
 * More codecs may be registered through calls to the library
 * and/or the builtin implementations may be overridden.
 */
typedef	int (*TIFFInitMethod)(TIFF*, int);
typedef struct {
	char*		name;
	uint16		scheme;
	TIFFInitMethod	init;
} TIFFCodec;

#include <stdio.h>
#include <stdarg.h>

#if defined(__cplusplus)
extern "C" {
#endif
typedef	void (*TIFFErrorHandler)(const char*, const char*, va_list);
typedef	tsize_t (*TIFFReadWriteProc)(thandle_t, tdata_t, tsize_t);
typedef	toff_t (*TIFFSeekProc)(thandle_t, toff_t, int);
typedef	int (*TIFFCloseProc)(thandle_t);
typedef	toff_t (*TIFFSizeProc)(thandle_t);
typedef	int (*TIFFMapFileProc)(thandle_t, tdata_t*, toff_t*);
typedef	void (*TIFFUnmapFileProc)(thandle_t, tdata_t, toff_t);
typedef	void (*TIFFExtendProc)(TIFF*); 

extern	TIFF_EXPORT(const char *,TIFFGetVersion) TIFF_ARGS((void));

extern	TIFF_EXPORT(const TIFFCodec *, TIFFFindCODEC) TIFF_ARGS((uint16));
extern	TIFF_EXPORT(TIFFCodec *, TIFFRegisterCODEC) TIFF_ARGS((uint16, const char*, TIFFInitMethod));
extern	TIFF_EXPORT(void, TIFFUnRegisterCODEC) TIFF_ARGS((TIFFCodec*));

extern	TIFF_EXPORT(tdata_t, _TIFFmalloc) TIFF_ARGS((tsize_t));
extern	TIFF_EXPORT(tdata_t, _TIFFrealloc) TIFF_ARGS((tdata_t, tsize_t));
extern	TIFF_EXPORT(void, _TIFFmemset) TIFF_ARGS((tdata_t, int, tsize_t));
extern	TIFF_EXPORT(void, _TIFFmemcpy) TIFF_ARGS((tdata_t, const tdata_t, tsize_t));
extern	TIFF_EXPORT(int, _TIFFmemcmp) TIFF_ARGS((const tdata_t, const tdata_t, tsize_t));
extern	TIFF_EXPORT(void, _TIFFfree) TIFF_ARGS((tdata_t));

extern	TIFF_EXPORT(void, TIFFClose) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(int, TIFFFlush) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(int, TIFFFlushData) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(int, TIFFGetField) TIFF_ARGS((TIFF*, ttag_t, ...));
extern	TIFF_EXPORT(int, TIFFVGetField) TIFF_ARGS((TIFF*, ttag_t, va_list));
extern	TIFF_EXPORT(int, TIFFGetFieldDefaulted) TIFF_ARGS((TIFF*, ttag_t, ...));
extern	TIFF_EXPORT(int, TIFFVGetFieldDefaulted) TIFF_ARGS((TIFF*, ttag_t, va_list));
extern	TIFF_EXPORT(int, TIFFReadDirectory) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(tsize_t, TIFFScanlineSize) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(tsize_t, TIFFRasterScanlineSize) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(tsize_t, TIFFStripSize) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(tsize_t, TIFFVStripSize) TIFF_ARGS((TIFF*, uint32));
extern	TIFF_EXPORT(tsize_t, TIFFTileRowSize) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(tsize_t, TIFFTileSize) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(tsize_t, TIFFVTileSize) TIFF_ARGS((TIFF*, uint32));
extern	TIFF_EXPORT(uint32, TIFFDefaultStripSize) TIFF_ARGS((TIFF*, uint32));
extern	TIFF_EXPORT(void, TIFFDefaultTileSize) TIFF_ARGS((TIFF*, uint32*, uint32*));
extern	TIFF_EXPORT(int, TIFFFileno) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(int, TIFFGetMode) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(int, TIFFIsTiled) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(int, TIFFIsByteSwapped) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(int, TIFFIsUpSampled) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(int, TIFFIsMSB2LSB) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(uint32, TIFFCurrentRow) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(tdir_t, TIFFCurrentDirectory) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(tdir_t, TIFFNumberOfDirectories) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(uint32, TIFFCurrentDirOffset) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(tstrip_t, TIFFCurrentStrip) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(ttile_t, TIFFCurrentTile) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(int, TIFFReadBufferSetup) TIFF_ARGS((TIFF*, tdata_t, tsize_t));
extern	TIFF_EXPORT(int, TIFFWriteBufferSetup) TIFF_ARGS((TIFF*, tdata_t, tsize_t));
extern	TIFF_EXPORT(int, TIFFWriteCheck) TIFF_ARGS((TIFF*, int, const char *));
extern	TIFF_EXPORT(int, TIFFCreateDirectory) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(int, TIFFLastDirectory) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(int, TIFFSetDirectory) TIFF_ARGS((TIFF*, tdir_t));
extern	TIFF_EXPORT(int, TIFFSetSubDirectory) TIFF_ARGS((TIFF*, uint32));
extern	TIFF_EXPORT(int, TIFFUnlinkDirectory) TIFF_ARGS((TIFF*, tdir_t));
extern	TIFF_EXPORT(int, TIFFSetField) TIFF_ARGS((TIFF*, ttag_t, ...));
extern	TIFF_EXPORT(int, TIFFVSetField) TIFF_ARGS((TIFF*, ttag_t, va_list));
extern	TIFF_EXPORT(int, TIFFWriteDirectory) TIFF_ARGS((TIFF *));
extern	TIFF_EXPORT(int, TIFFReassignTagToIgnore) TIFF_ARGS((enum TIFFIgnoreSense, int));

#if defined(c_plusplus) || defined(__cplusplus)
extern	TIFF_EXPORT(void, TIFFPrintDirectory) TIFF_ARGS((TIFF*, FILE*, long = 0));
extern	TIFF_EXPORT(int, TIFFReadScanline) TIFF_ARGS((TIFF*, tdata_t, uint32, tsample_t = 0));
extern	TIFF_EXPORT(int, TIFFWriteScanline) TIFF_ARGS((TIFF*, tdata_t, uint32, tsample_t = 0));
extern	TIFF_EXPORT(int, TIFFReadRGBAImage) TIFF_ARGS((TIFF*, uint32, uint32, uint32*, int = 0));
#else
extern	TIFF_EXPORT(void, TIFFPrintDirectory) TIFF_ARGS((TIFF*, FILE*, long));
extern	TIFF_EXPORT(int, TIFFReadScanline) TIFF_ARGS((TIFF*, tdata_t, uint32, tsample_t));
extern	TIFF_EXPORT(int, TIFFWriteScanline) TIFF_ARGS((TIFF*, tdata_t, uint32, tsample_t));
extern	TIFF_EXPORT(int, TIFFReadRGBAImage) TIFF_ARGS((TIFF*, uint32, uint32, uint32*, int));
#endif

extern	TIFF_EXPORT(int, TIFFReadRGBAStrip) TIFF_ARGS((TIFF*, tstrip_t, uint32 * ));
extern	TIFF_EXPORT(int, TIFFReadRGBATile) TIFF_ARGS((TIFF*, uint32, uint32, uint32 * ));
extern	TIFF_EXPORT(int, TIFFRGBAImageOK) TIFF_ARGS((TIFF*, char [1024]));
extern	TIFF_EXPORT(int, TIFFRGBAImageBegin) TIFF_ARGS((TIFFRGBAImage*, TIFF*, int, char [1024]));
extern	TIFF_EXPORT(int, TIFFRGBAImageGet) TIFF_ARGS((TIFFRGBAImage*, uint32*, uint32, uint32));
extern	TIFF_EXPORT(void, TIFFRGBAImageEnd) TIFF_ARGS((TIFFRGBAImage*));
extern	TIFF_EXPORT(TIFF *, TIFFOpen) TIFF_ARGS((const char*, const char*));
extern	TIFF_EXPORT(TIFF *, TIFFFdOpen) TIFF_ARGS((int, const char*, const char*));
extern	TIFF_EXPORT(TIFF *, TIFFClientOpen) TIFF_ARGS((const char*, const char*, \
	    thandle_t, \
	    TIFFReadWriteProc, TIFFReadWriteProc, \
	    TIFFSeekProc, TIFFCloseProc, \
	    TIFFSizeProc, \
	    TIFFMapFileProc, TIFFUnmapFileProc));
extern	TIFF_EXPORT(const char*, TIFFFileName) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(void, TIFFError) TIFF_ARGS((const char*, const char*, ...));
extern	TIFF_EXPORT(void, TIFFWarning) TIFF_ARGS((const char*, const char*, ...));
extern	TIFF_EXPORT(TIFFErrorHandler, TIFFSetErrorHandler) TIFF_ARGS((TIFFErrorHandler));
extern	TIFF_EXPORT(TIFFErrorHandler, TIFFSetWarningHandler) TIFF_ARGS((TIFFErrorHandler));
extern	TIFF_EXPORT(TIFFExtendProc, TIFFSetTagExtender) TIFF_ARGS((TIFFExtendProc));
extern	TIFF_EXPORT(ttile_t, TIFFComputeTile) TIFF_ARGS((TIFF*, uint32, uint32, uint32, tsample_t));
extern	TIFF_EXPORT(int, TIFFCheckTile) TIFF_ARGS((TIFF*, uint32, uint32, uint32, tsample_t));
extern	TIFF_EXPORT(ttile_t, TIFFNumberOfTiles) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(tsize_t, TIFFReadTile) TIFF_ARGS((TIFF*, \
	    tdata_t, uint32, uint32, uint32, tsample_t));
extern	TIFF_EXPORT(tsize_t, TIFFWriteTile) TIFF_ARGS((TIFF*, \
	    tdata_t, uint32, uint32, uint32, tsample_t));
extern	TIFF_EXPORT(tstrip_t, TIFFComputeStrip) TIFF_ARGS((TIFF*, uint32, tsample_t));
extern	TIFF_EXPORT(tstrip_t, TIFFNumberOfStrips) TIFF_ARGS((TIFF*));
extern	TIFF_EXPORT(tsize_t, TIFFReadEncodedStrip) TIFF_ARGS((TIFF*, tstrip_t, tdata_t, tsize_t));
extern	TIFF_EXPORT(tsize_t, TIFFReadRawStrip) TIFF_ARGS((TIFF*, tstrip_t, tdata_t, tsize_t));
extern	TIFF_EXPORT(tsize_t, TIFFReadEncodedTile) TIFF_ARGS((TIFF*, ttile_t, tdata_t, tsize_t));
extern	TIFF_EXPORT(tsize_t, TIFFReadRawTile) TIFF_ARGS((TIFF*, ttile_t, tdata_t, tsize_t));
extern	TIFF_EXPORT(tsize_t, TIFFWriteEncodedStrip) TIFF_ARGS((TIFF*, tstrip_t, tdata_t, tsize_t));
extern	TIFF_EXPORT(tsize_t, TIFFWriteRawStrip) TIFF_ARGS((TIFF*, tstrip_t, tdata_t, tsize_t));
extern	TIFF_EXPORT(tsize_t, TIFFWriteEncodedTile) TIFF_ARGS((TIFF*, ttile_t, tdata_t, tsize_t));
extern	TIFF_EXPORT(tsize_t, TIFFWriteRawTile) TIFF_ARGS((TIFF*, ttile_t, tdata_t, tsize_t));
extern	TIFF_EXPORT(void, TIFFSetWriteOffset) TIFF_ARGS((TIFF*, toff_t));
extern	TIFF_EXPORT(void, TIFFSwabShort) TIFF_ARGS((uint16*));
extern	TIFF_EXPORT(void, TIFFSwabLong) TIFF_ARGS((uint32*));
extern	TIFF_EXPORT(void, TIFFSwabDouble) TIFF_ARGS((double*));
extern	TIFF_EXPORT(void, TIFFSwabArrayOfShort) TIFF_ARGS((uint16*, unsigned long));
extern	TIFF_EXPORT(void, TIFFSwabArrayOfLong) TIFF_ARGS((uint32*, unsigned long));
extern	TIFF_EXPORT(void, TIFFSwabArrayOfDouble) TIFF_ARGS((double*, unsigned long));
extern	TIFF_EXPORT(void, TIFFReverseBits) TIFF_ARGS((unsigned char *, unsigned long));
extern	TIFF_EXPORT(const unsigned char*, TIFFGetBitRevTable) TIFF_ARGS((int));
#if defined(__cplusplus)
}
#endif
#endif /* _TIFFIO_ */
