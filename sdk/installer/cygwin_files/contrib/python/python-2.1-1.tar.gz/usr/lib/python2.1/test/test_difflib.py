import doctest, difflib
doctest.testmod(difflib, verbose=1)
