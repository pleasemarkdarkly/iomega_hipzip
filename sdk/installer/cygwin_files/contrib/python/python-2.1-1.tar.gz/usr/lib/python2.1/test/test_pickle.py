import pickle
import pickletester
pickletester.dotest(pickle)
