import cPickle
import pickletester
pickletester.dotest(cPickle)
