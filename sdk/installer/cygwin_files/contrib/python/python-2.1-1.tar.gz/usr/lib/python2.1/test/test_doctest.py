import doctest
doctest.testmod(doctest, verbose=1)
