"""distutils

The main package for the Python Module Distribtion Utilities.  Normally
used from a setup script as

   from distutils.core import setup

   setup (...)
"""

__revision__ = "$Id: __init__.py,v 1.19 2001/03/16 21:00:18 theller Exp $"

__version__ = "1.0.2pre"
