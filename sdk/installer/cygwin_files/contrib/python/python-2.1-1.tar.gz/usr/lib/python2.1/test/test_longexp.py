REPS = 65580

l = eval("[" + "2," * REPS + "]")
print len(l)
