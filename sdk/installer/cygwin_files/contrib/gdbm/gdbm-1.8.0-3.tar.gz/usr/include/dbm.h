/* dbm.h  -  The include file for dbm users.  */

/*  This file is part of GDBM, the GNU data base manager, by Philip A. Nelson.
    Copyright (C) 1990, 1991, 1993  Free Software Foundation, Inc.

    GDBM is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2, or (at your option)
    any later version.

    GDBM is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with GDBM; see the file COPYING.  If not, write to
    the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

    You may contact the author by:
       e-mail:  phil@cs.wwu.edu
      us-mail:  Philip A. Nelson
                Computer Science Department
                Western Washington University
                Bellingham, WA 98226
       
*************************************************************************/

#if defined(__CYGWIN__)
#  if defined(GDBM_DLL)
#    if defined(GDBM_STATIC)
#      undef GDBM_STATIC
#    endif
#  endif
#  if defined(GDBM_DLL)
/* building a DLL */
#    define GDBM_IMPEXP __declspec(dllexport)
#  elif defined(GDBM_STATIC)
/* building or linking to a static library */
#    define GDBM_IMPEXP
#  else
/* linking to the DLL */
#    define GDBM_IMPEXP __declspec(dllimport)
#  endif

#  if !defined(GDBM_API)
#    define GDBM_API __cdecl
#  endif
#  if !defined(GDBM_EXPORT)
#    define GDBM_EXPORT(type,symbol) GDBM_IMPEXP type GDBM_API symbol
#  endif
#  if !defined(GDBM_EXPORT_VAR)
#    define GDBM_EXPORT_VAR(type) GDBM_IMPEXP type
#  endif
#endif

#if !defined(GDBM_IMPEXP)
#  define GDBM_IMPEXP
#endif
#if !defined(GDBM_API)
#  define GDBM_API
#endif
#if !defined(GDBM_EXPORT)
#  define GDBM_EXPORT(type,symbol) GDBM_IMPEXP type GDBM_API symbol
#endif
#if !defined(GDBM_EXPORT_VAR)
#  define GDBM_EXPORT_VAR(type) GDBM_IMPEXP type
#endif
  
/* The data and key structure.  This structure is defined for compatibility. */
typedef struct {
	char *dptr;
	int   dsize;
      } datum;


/* These are the routines in dbm. */

extern GDBM_EXPORT(int,	dbminit) ();

extern GDBM_EXPORT(datum,	fetch) ();

extern GDBM_EXPORT(int,	store) ();

extern GDBM_EXPORT(int,	delete) ();

extern GDBM_EXPORT(datum,	firstkey) ();

extern GDBM_EXPORT(datum,	nextkey) ();

extern GDBM_EXPORT(int,	dbmclose) ();
